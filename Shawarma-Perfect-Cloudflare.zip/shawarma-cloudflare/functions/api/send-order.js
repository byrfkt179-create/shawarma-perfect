// Cloudflare Pages Function: POST /api/send-order
// Uploads the generated invoice PNG to WhatsApp Cloud API and sends it
// to the restaurant using an approved image-header message template.

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
});

export async function onRequestPost({ request, env }) {
  // Browser requests from the same Pages site are expected. Reject cross-site
  // browser submissions when an Origin header is present.
  const origin = request.headers.get("Origin");
  if (origin) {
    try {
      if (new URL(origin).origin !== new URL(request.url).origin) {
        return json({ ok: false, error: "مصدر الطلب غير مسموح." }, 403);
      }
    } catch {
      return json({ ok: false, error: "تعذر التحقق من مصدر الطلب." }, 403);
    }
  }

  if (!(request.headers.get("Content-Type") || "").includes("application/json")) {
    return json({ ok: false, error: "صيغة الطلب غير صحيحة." }, 415);
  }

  const token = env.WA_ACCESS_TOKEN;
  const phoneNumberId = env.WA_PHONE_NUMBER_ID;
  const recipient = String(env.WA_RESTAURANT_TO || "966505980900").replace(/\D/g, "");
  const templateName = env.WA_TEMPLATE_NAME || "new_order_invoice";
  const language = env.WA_TEMPLATE_LANG || "ar";
  const version = env.WA_API_VERSION || "v27.0";

  if (!token || !phoneNumberId) {
    return json({ ok: false, error: "لم تكتمل إعدادات WhatsApp Business API في Cloudflare." }, 503);
  }

  let input;
  try {
    // Limit request size before parsing; invoice is expected to be a small PNG.
    const raw = await request.text();
    if (raw.length > 7_500_000) return json({ ok: false, error: "حجم بيانات الفاتورة كبير جداً." }, 413);
    input = JSON.parse(raw);
  } catch {
    return json({ ok: false, error: "تعذر قراءة بيانات الطلب." }, 400);
  }

  const order = input?.order || {};
  const base64 = String(input?.invoice || "").replace(/^data:image\/png;base64,/, "").replace(/\s/g, "");
  if (!base64 || !order.number || !order.name || !order.total) {
    return json({ ok: false, error: "بيانات الفاتورة غير مكتملة." }, 400);
  }
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(base64) || base64.length % 4 !== 0) {
    return json({ ok: false, error: "صيغة صورة الفاتورة غير صالحة." }, 400);
  }

  let bytes;
  try {
    const binary = atob(base64);
    if (binary.length > 5 * 1024 * 1024) {
      return json({ ok: false, error: "حجم صورة الفاتورة أكبر من 5 ميجابايت." }, 413);
    }
    bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    // PNG signature check
    const sig = [137, 80, 78, 71, 13, 10, 26, 10];
    if (!sig.every((v, i) => bytes[i] === v)) {
      return json({ ok: false, error: "الملف المرسل ليس صورة PNG صالحة." }, 400);
    }
  } catch {
    return json({ ok: false, error: "تعذر فك صورة الفاتورة." }, 400);
  }

  try {
    // 1) Upload invoice image to Meta media storage.
    const form = new FormData();
    form.append("messaging_product", "whatsapp");
    form.append("type", "image/png");
    form.append("file", new Blob([bytes], { type: "image/png" }), `invoice-${String(order.number)}.png`);

    const upload = await fetch(`https://graph.facebook.com/${version}/${phoneNumberId}/media`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body: form,
    });
    const mediaResult = await upload.json().catch(() => ({}));
    if (!upload.ok || !mediaResult.id) {
      return json({ ok: false, error: mediaResult?.error?.message || "فشل رفع صورة الفاتورة إلى واتساب." }, 502);
    }

    // 2) Send the uploaded image in the HEADER of an approved WhatsApp template.
    const details = [
      `رقم الطلب: ${order.number}`,
      `العميل: ${order.name}`,
      `الجوال: ${order.phone || "-"}`,
      `نوع الطلب: ${order.type || "-"}`,
      `الإجمالي: ${order.total}`,
      order.note ? `ملاحظات: ${order.note}` : "",
      order.map ? `الموقع: ${order.map}` : "",
    ].filter(Boolean).join(" | ").slice(0, 1024);

    const send = await fetch(`https://graph.facebook.com/${version}/${phoneNumberId}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: recipient,
        type: "template",
        template: {
          name: templateName,
          language: { code: language },
          components: [
            { type: "header", parameters: [{ type: "image", image: { id: mediaResult.id } }] },
            { type: "body", parameters: [{ type: "text", text: details }] },
          ],
        },
      }),
    });
    const result = await send.json().catch(() => ({}));
    if (!send.ok) {
      return json({ ok: false, error: result?.error?.message || "رفض واتساب إرسال الفاتورة. تحقق من القالب ورقم الاستقبال." }, 502);
    }

    return json({ ok: true, messageId: result?.messages?.[0]?.id || null });
  } catch (error) {
    return json({ ok: false, error: error?.message || "حدث خطأ أثناء إرسال الفاتورة." }, 500);
  }
}

export async function onRequest(context) {
  if (context.request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: { "Allow": "POST, OPTIONS" } });
  }
  if (context.request.method !== "POST") {
    return json({ ok: false, error: "الطريقة غير مسموحة." }, 405);
  }
  return onRequestPost(context);
}
